using System;
using Client;

namespace CloudBall
{
#if WINDOWS || XBOX
    static class RunCloudBall
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            using (Client.Client game = new Client.Client(new TeamOne.TeamOne(), new TeamTwo.TeamTwo()))
            {
                game.Run();
            }
        }
    }
#endif
}

